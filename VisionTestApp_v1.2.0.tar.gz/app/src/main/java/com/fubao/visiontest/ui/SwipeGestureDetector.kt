package com.fubao.visiontest.ui

import android.content.Context
import android.graphics.Bitmap
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.abs

/**
 * 滑动手势类型 - 手指划动方向对应 E 字开口方向
 */
enum class SwipeGestureType {
    SWIPE_UP,        // 手指向上滑 → E 口朝上
    SWIPE_DOWN,      // 手指向下滑 → E 口朝下
    SWIPE_LEFT,      // 手指向左滑 → E 口朝左
    SWIPE_RIGHT,     // 手指向右滑 → E 口朝右
    NONE             // 无滑动
}

/**
 * 滑动轨迹点
 */
data class SwipePoint(
    val x: Float,
    val y: Float,
    val timestamp: Long
)

/**
 * 滑动跟踪数据
 */
data class SwipeTrackingData(
    val points: List<SwipePoint>,
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float,
    val startTime: Long,
    val endTime: Long
) {
    /**
     * 计算滑动位移
     */
    fun getDeltaX(): Float = endX - startX
    
    fun getDeltaY(): Float = endY - startY
    
    /**
     * 判断滑动方向
     * @param thresholdX X 轴最小滑动阈值（像素）
     * @param thresholdY Y 轴最小滑动阈值（像素）
     */
    fun detectDirection(thresholdX: Float = 30f, thresholdY: Float = 30f): SwipeGestureType {
        val deltaX = getDeltaX()
        val deltaY = getDeltaY()
        
        val absDx = abs(deltaX)
        val absDy = abs(deltaY)
        
        return when {
            // 优先判断长边滑动（避免误触）
            absDx > absDy -> {
                if (absDx > thresholdX) {
                    when {
                        deltaX > 0 -> SwipeGestureType.SWIPE_RIGHT   // 向右滑 → E 口朝右
                        else -> SwipeGestureType.SWIPE_LEFT         // 向左滑 → E 口朝左
                    }
                } else {
                    SwipeGestureType.NONE
                }
            }
            absDy > thresholdY -> {
                when {
                    deltaY > 0 -> SwipeGestureType.SWIPE_DOWN   // 向下滑 → E 口朝下
                    else -> SwipeGestureType.SWIPE_UP           // 向上滑 → E 口朝上
                }
            }
            else -> SwipeGestureType.NONE
        }
    }
    
    /**
     * 计算滑动速度
     */
    fun getVelocity(): Float {
        val duration = (endTime - startTime).toFloat()
        if (duration <= 0) return 0f
        
        val displacement = kotlin.math.sqrt((deltaX * deltaX) + (deltaY * deltaY))
        return displacement / duration
    }
}

/**
 * 滑动事件记录
 */
data class SwipeEvent(
    val direction: SwipeGestureType,
    val velocity: Float,
    val displacement: Float,
    val timestamp: Long
)

class CameraGestureDetector(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {
    // 滑动检测状态
    private var gestureStartTime: Long = 0
    private var gestureStartX: Float? = null
    private var gestureStartY: Float? = null
    private var lastValidGesture: SwipeGestureType = SwipeGestureType.NONE
    private val swipeHistory = mutableListOf<SwipeEvent>()
    
    private val _gestureDetected = MutableStateFlow<GestureStatus>(GestureStatus.Idle)
    val gestureDetected: StateFlow<GestureStatus> = _gestureDetected.asStateFlow()
    
    enum class GestureStatus {
        Idle, DetectingLeft, DetectingRight, DetectingUp, DetectingDown, Error
    }
    
    /**
     * 获取当前检测到的滑动手势
     * 在实际应用中，这里应该返回从图像中检测到的实际手部移动
     */
    fun getCurrentSwipeGesture(): SwipeGestureType {
        // TODO: 集成真实的 ML Kit Pose Detection 来获取手部位置
        // 这里是模拟实现
        
        // 在实际使用中，需要从摄像头画面中追踪手部位置变化
        // 当检测到有效滑动时，返回对应的方向
        
        return lastValidGesture
    }
    
    /**
     * 更新滑动状态（从摄像头图像中提取手部位置变化）
     * @param currentHandPosition 当前检测到手的中心位置
     */
    fun updateSwipePosition(currentHandPosition: Pair<Float, Float>) {
        val (currentX, currentY) = currentHandPosition
        
        if (gestureStartX == null || gestureStartY == null) {
            // 第一次检测到手部，记录起始点
            gestureStartX = currentX
            gestureStartY = currentY
            gestureStartTime = System.currentTimeMillis()
        } else {
            // 计算滑动距离和时间
            val trackingData = SwipeTrackingData(
                points = emptyList(), // TODO: 保存完整轨迹
                startX = gestureStartX!!,
                startY = gestureStartY!!,
                endX = currentX,
                endY = currentY,
                startTime = gestureStartTime,
                endTime = System.currentTimeMillis()
            )
            
            // 检测滑动方向
            val direction = trackingData.detectDirection(25f, 25f)
            
            if (direction != SwipeGestureType.NONE && direction != lastValidGesture) {
                lastValidGesture = direction
                
                // 映射到 UI 状态
                _gestureDetected.value = mapGestureToUIStatus(direction)
                
                // 记录事件
                val event = SwipeEvent(
                    direction = direction,
                    velocity = trackingData.getVelocity(),
                    displacement = kotlin.math.sqrt((trackingData.getDeltaX().pow(2.0) + 
                                                     trackingData.getDeltaY().pow(2.0)).toDouble()).toFloat(),
                    timestamp = System.currentTimeMillis()
                )
                swipeHistory.add(event)
            }
        }
    }
    
    /**
     * 将滑动手势映射到 UI 显示状态
     */
    private fun mapGestureToUIStatus(gesture: SwipeGestureType): GestureStatus {
        return when (gesture) {
            SwipeGestureType.SWIPE_UP -> GestureStatus.DetectingUp
            SwipeGestureType.SWIPE_DOWN -> GestureStatus.DetectingDown
            SwipeGestureType.SWIPE_LEFT -> GestureStatus.DetectingLeft
            SwipeGestureType.SWIPE_RIGHT -> GestureStatus.DetectingRight
            SwipeGestureType.NONE -> GestureStatus.Idle
        }
    }
    
    /**
     * 重置滑动检测状态
     */
    fun resetSwipe() {
        gestureStartX = null
        gestureStartY = null
        gestureStartTime = 0
        lastValidGesture = SwipeGestureType.NONE
        swipeHistory.clear()
        _gestureDetected.value = GestureStatus.Idle
    }
    
    /**
     * 获取滑动历史统计
     */
    fun getSwipeStatistics(): SwipeStats {
        if (swipeHistory.isEmpty()) {
            return SwipeStats.empty
        }
        
        val totalSwipes = swipeHistory.size
        val validSwipes = swipeHistory.count { it.displacement > 10f }
        val avgVelocity = swipeHistory.map { it.velocity }.average()
        
        return SwipeStats(
            totalSwipes = totalSwipes,
            validSwipes = validSwipes,
            averageVelocity = avgVelocity.toFloat(),
            lastGesture = lastValidGesture
        )
    }
    
    fun startCamera(previewView: PreviewView, imageAnalysis: ImageAnalysis) {
        try {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()
                
                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    androidx.camera.view.Preview.Builder().build().also { preview ->
                        previewView.preview = it
                    },
                    imageAnalysis
                )
            }, ContextCompat.getMainExecutor(context))
            
        } catch (e: Exception) {
            _gestureDetected.value = GestureStatus.Error
        }
    }
    
    fun analyzeImage(imageProxy: ImageProxy) {
        // TODO: 集成 ML Kit Pose Detection 来追踪手部位置
        // 这里仅作为占位符，实际应提取手部中心坐标
        
        try {
            val bitmap = imageProxy.toBitmap()
            val centerX = bitmap.width / 2f
            val centerY = bitmap.height / 2f
            
            // 在真实应用中，这里应该通过计算机视觉算法检测手部并返回其中心坐标
            // 例如：使用 ML Kit Face Detection 或 Pose Detection API
            
            // 为演示目的，模拟手部位置变化
            // 实际使用时请替换为真实的检测逻辑
            updateSwipePosition(currentHandPosition = Pair(centerX, centerY))
            
        } finally {
            imageProxy.close()
        }
    }
    
    fun stopCamera(cameraProvider: ProcessCameraProvider) {
        cameraProvider.unbindAll()
    }
    
    data class SwipeStats(
        val totalSwipes: Int,
        val validSwipes: Int,
        val averageVelocity: Float,
        val lastGesture: SwipeGestureType
    ) {
        companion object {
            val empty = SwipeStats(0, 0, 0f, SwipeGestureType.NONE)
        }
    }
}

fun Float.pow(exponent: Double): Double {
    return this.toDouble().pow(exponent)
}
