package com.fubao.visiontest.ui

import android.content.Context
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mlkit.pose.detection.PoseDetectorOptions
import com.google.mlkit.pose.detection.Poses
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.nio.ByteBuffer
import kotlin.math.abs

class CameraGestureDetector(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {
    private val _gestureDetected = MutableStateFlow<GestureStatus>(GestureStatus.Idle)
    val gestureDetected: StateFlow<GestureStatus> = _gestureDetected.asStateFlow()
    
    enum class GestureStatus {
        Idle, DetectingLeft, DetectingRight, DetectingUp, DetectingDown, Error
    }
    
    private var poseDetector: Any? = null // ML Kit detector
    
    fun startCamera(previewView: PreviewView, imageAnalysis: ImageAnalysis) {
        try {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()
                
                // 选择后置摄像头
                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                
                // 绑定生命周期
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    androidx.camera.view.Preview.Builder().build().also { preview ->
                        previewView.preview = it
                    },
                    imageAnalysis
                )
            }, ContextCompat.getMainExecutor(context))
            
        } catch (e: Exception) {
            _gestureDetected.value = GestureStatus.Error
        }
    }
    
    fun analyzeImage(imageProxy: ImageProxy) {
        // TODO: 集成 ML Kit Pose Detection 来识别手部姿势
        // 这里实现简化版，使用简单的图像分析
        
        try {
            val bitmap = imageProxy.toBitmap()
            
            // 提取中心区域的手势信息
            val centerX = bitmap.width / 2
            val centerY = bitmap.height / 2
            val centerRegion = extractCenterRegion(bitmap, centerX, centerY, 100)
            
            // 简化：根据中心区域的颜色和形状特征判断手势
            val gesture = detectSimpleGesture(centerRegion)
            
            updateGestureStatus(gesture)
            
        } finally {
            imageProxy.close()
        }
    }
    
    private fun extractCenterRegion(bitmap: Bitmap, x: Int, y: Int, size: Int): Bitmap {
        val left = maxOf(0, x - size / 2)
        val top = maxOf(0, y - size / 2)
        val right = minOf(bitmap.width, x + size / 2)
        val bottom = minOf(bitmap.height, y + size / 2)
        
        return Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
    }
    
    // 简化的手势检测逻辑（实际应使用 ML Kit）
    private fun detectSimpleGesture(region: Bitmap): HandGesture {
        // 计算区域的亮度和对比度
        var sumIntensity = 0f
        var sumVariance = 0f
        var pixelCount = 0
        
        for (y in 0 until region.height) {
            for (x in 0 until region.width) {
                val color = region.getPixel(x, y)
                val intensity = (color shr 16 and 0xFF) * 0.3f + 
                              (color shr 8 and 0xFF) * 0.59f + 
                              (color and 0xFF) * 0.11f
                
                sumIntensity += intensity
                sumVariance += (intensity - sumIntensity / (pixelCount + 1)).pow(2.0)
                pixelCount++
            }
        }
        
        val avgIntensity = if (pixelCount > 0) sumIntensity / pixelCount else 0f
        val variance = if (pixelCount > 0) sumVariance / pixelCount else 0f
        
        // 基于简单特征的分类（placeholder logic）
        return when {
            avgIntensity > 180f && variance < 500f -> HandGesture.Pinch // 捏合
            avgIntensity > 200f && variance > 500f -> HandGesture.OpenHand // 张开手掌
            avgIntensity < 150f -> HandGesture.Fist // 握拳
            else -> HandGesture.None
        }
    }
    
    private fun updateGestureStatus(gesture: HandGesture) {
        _gestureDetected.value = when (gesture) {
            HandGesture.Pinch -> GestureStatus.DetectingUp // 捏合表示看到上方 E
            HandGesture.OK -> GestureStatus.DetectingLeft // OK 表示看到左侧 E
            HandGesture.Fist -> GestureStatus.DetectingRight // 握拳表示看到右侧 E  
            HandGesture.OpenHand -> GestureStatus.DetectingDown // 张开表示看到下方 E
            else -> GestureStatus.Idle
        }
    }
    
    fun stopCamera(cameraProvider: ProcessCameraProvider) {
        cameraProvider.unbindAll()
    }
}

data class HandGestureInfo(
    val gesture: HandGesture,
    val confidence: Float,
    val timestamp: Long
)

enum class HandGesture {
    Pinch, OK, Fist, OpenHand, None
}

/**
 * 计算屏幕尺寸以调整视标大小
 */
object ScreenScaler {
    /**
     * 获取屏幕对角线长度（英寸）
     */
    fun getScreenDiagonalInches(context: Context): Double {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)
        
        val widthInches = metrics.widthPixels / metrics.xdpi
        val heightInches = metrics.heightPixels / metrics.ydpi
        
        return kotlin.math.sqrt(widthInches.pow(2.0) + heightInches.pow(2.0))
    }
    
    /**
     * 根据观看距离调整视标大小
     * @param baseSize 基础尺寸（mm）
     * @param viewingDistanceCm 观看距离（厘米）
     * @return 调整后的尺寸比例
     */
    fun adjustSizeForDistance(baseSize: Float, viewingDistanceCm: Double): Float {
        // 标准距离为 50cm
        val standardDistance = 50.0
        val ratio = standardDistance / viewingDistanceCm
        
        return (baseSize * ratio).toFloat()
    }
    
    /**
     * 估算用户的观看距离（通过深度传感器或用户输入）
     */
    fun estimateViewingDistance(): Double {
        // 实际应用中应该：
        // 1. 尝试读取深度传感器数据
        // 2. 如果没有，提示用户输入或自动估计
        
        // 这里默认返回标准距离
        return 50.0 // cm
    }
}

fun ByteBuffer.toDoubleArray(): DoubleArray {
    val array = DoubleArray(this.remaining() / 8)
    for (i in array.indices) {
        array[i] = this.getDouble()
    }
    return array
}

private fun Double.pow(exponent: Double): Double {
    return kotlin.math.pow(this, exponent)
}
