package com.fubao.visiontest

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fubao.visiontest.data.EyeChartCalculator
import com.fubao.visiontest.data.EyeChartResult
import com.fubao.visiontest.ui.DistanceAndGestureDetector
import com.fubao.visiontest.ui.DistanceEstimate
import com.fubao.visiontest.ui.SwipeGestureType
import com.fubao.visiontest.ui.WaveStatus

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VisionTestTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    EyeChartScreen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EyeChartScreen(
    modifier: Modifier = Modifier
) {
    var currentLineIndex by remember { mutableIntStateOf(0) }
    var isTesting by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(emptyList<EyeChartResult>()) }
    var visionSummary by remember { mutablePair(0.0, 0.0) }
    
    // 手势和距离检测器
    val detector = remember { DistanceAndGestureDetector(this, this) }
    var swipeDirection by remember { mutableStateOf<SwipeGestureType?>(null) }
    var waveDetected by remember { mutableStateOf(false) }
    var distanceStatus by remember { mutableStateOf<DistanceEstimate>(DistanceEstimate.UNKNOWN) }
    
    val viewModel = remember { ViewModelHelper() }
    val testResults = viewModel.testResults
    
    // 监听滑动手势并处理结果（看到 E 字方向时的操作）
    LaunchedEffect(swipeDirection) {
        if (swipeDirection != null && !waveDetected) {
            when (swipeDirection) {
                SwipeGestureType.SWIPE_UP, SwipeGestureType.SWIPE_DOWN, 
                SwipeGestureType.SWIPE_LEFT, SwipeGestureType.SWIPE_RIGHT -> {
                    // 滑动表示"看到了"，自动进入下一行
                    viewModel.addResult(EyeChartResult(
                        lineIndex = currentLineIndex,
                        视力值 = calculateCurrentVisionValue(currentLineIndex),
                        snellen = EyeChartCalculator.snellenFromVisionValue(calculateCurrentVisionValue(currentLineIndex)),
                        isCorrect = true,
                        timestamp = System.currentTimeMillis(),
                        swipeDirection = swipeDirection
                    ))
                    
                    // 获取最新的当前行号
                    currentLineIndex = viewModel.currentLineIndex.value
                }
            }
            swipeDirection = null
            waveDetected = false
            
            // 计算总结
            val summary = viewModel.getResultSummary()
            visionSummary = summary
        }
    }
    
    // 监听挥手检测结果（看不到 E 字时的操作）
    LaunchedEffect(waveDetected) {
        if (waveDetected) {
            // 挥手表示"没看到"，记录为错误但不进入下一行
            viewModel.recordHandWave(
                lineIndex = currentLineIndex,
                distanceStatus = distanceStatus
            )
            
            waveDetected = false
        }
    }
    
    // 监听距离状态变化
    LaunchedEffect(distanceStatus) {
        // 可以根据距离状态调整 UI 提示
    }
    
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopBarWithSettings(
            onReset = {
                currentLineIndex = 0
                results = emptyList()
                viewModel.clearResults()
                detector.resetAll()
            },
            onStartNewTest = {
                currentLineIndex = 0
                viewModel.clearResults()
                detector.resetAll()
                isTesting = true
            }
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // 距离检测状态卡片
        DistanceStatusCard(
            distanceEstimate = distanceStatus,
            scaleFactor = detector.getScaleFactorForDistance()
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // 挥手检测状态卡片
        WaveStatusCard(
            waveStatus = if (waveDetected) WaveStatus.WAVING_BOTH else WaveStatus.IDLE,
            onResetWave = { waveDetected = false }
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // 当前行信息
        CurrentLineInfo(
            lineIndex = currentLineIndex,
            totalLines = 13
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // E 字视力表显示（根据距离调整大小）
        EyeChartDisplay(
            rowIndex = currentLineIndex,
            sizeScale = detector.getScaleFactorForDistance()
        )
        
        Spacer(modifier = Modifier.height(48.dp))
        
        // 手势操作说明
        GestureInstructionCard()
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // 历史记录
        ResultsHistoryCard(
            results = testResults.take(20)
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // 视力总结
        VisionSummaryCard(summary = visionSummary)
        
        Spacer(modifier = Modifier.height(24.dp))
    }
    
    // TODO: 在真实应用中，这里应该连接摄像头进行实时检测
    // 实际使用时需要实现 CameraX 的图像分析回调
}

/**
 * 计算当前行的视力值
 */
private fun calculateCurrentVisionValue(rowIndex: Int): Double {
    return when (rowIndex) {
        0 -> 0.1   // 第 1 行（最大）
        1 -> 0.2
        2 -> 0.3
        3 -> 0.4
        4 -> 0.5
        5 -> 0.6
        6 -> 0.7
        7 -> 0.8
        8 -> 0.9
        9 -> 1.0
        10 -> 1.2
        11 -> 1.5
        12 -> 2.0  // 第 13 行（最小）
        else -> 1.0
    }
}

@Composable
fun TopBarWithSettings(
    onReset: () -> Unit,
    onStartNewTest: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "👁️ 智能视力检查",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = "Fubao AI 版 · v1.2.0",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                )
            }
            
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = onStartNewTest) {
                    Icon(Icons.Default.Refresh, contentDescription = "新测试")
                }
                
                IconButton(onClick = onReset) {
                    Icon(Icons.Default.Clear, contentDescription = "重置")
                }
            }
        }
    }
}

@Composable
fun DistanceStatusCard(
    distanceEstimate: DistanceEstimate,
    scaleFactor: Float
) {
    val (text, icon, color) = when (distanceEstimate) {
        DistanceEstimate.TOO_CLOSE -> 
            "请远离屏幕一点！当前太近" to "⚠️" to MaterialTheme.colorScheme.error
        
        DistanceEstimate.OPTIMAL -> 
            "✓ 距离适中" to "😌" to MaterialTheme.colorScheme.primary
        
        DistanceEstimate.TOO_FAR -> 
            "请靠近一点！当前太远" to "⚠️" to MaterialTheme.colorScheme.warning
        
        else -> 
            "等待距离检测..." to "🔍" to MaterialTheme.colorScheme.onSurfaceVariant
    }
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.1f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = icon, fontSize = 24.sp)
                Text(
                    text = text,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = color
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "视标已根据距离自动调整 (${String.format("%.1fx", scaleFactor)}倍)",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun WaveStatusCard(
    waveStatus: WaveStatus,
    onResetWave: () -> Unit
) {
    val (text, icon, showButton) = when (waveStatus) {
        WaveStatus.IDLE -> 
            "未检测到挥手" to "✋" to false
        
        WaveStatus.WAVEING_BOTH -> 
            "✅ 检测到挥手！已记录为"没看到"" to "🎉" to true
        
        else -> 
            "正在检测挥手动作..." to "🤔" to false
    }
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (showButton) 
                MaterialTheme.colorScheme.secondaryContainer 
            else 
                MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = icon, fontSize = 24.sp)
                Text(
                    text = text,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (showButton) 
                        MaterialTheme.colorScheme.onSecondaryContainer 
                    else 
                        MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            if (showButton) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onResetWave,
                    modifier = Modifier.widthIn(min = 120.dp)
                ) {
                    Text("确认已记录")
                }
            }
        }
    }
}

@Composable
fun CurrentLineInfo(lineIndex: Int, totalLines: Int) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "第 ${lineIndex + 1} / $totalLines 行",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "看清 E 字的开口方向，然后按对应方向滑动手指",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun EyeChartDisplay(rowIndex: Int, sizeScale: Float = 1f) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier.size((180.dp.toPx() * sizeScale).coerceAtMost(300.dp.toPx())).clip(CircleShape)
        ) {
            drawEye(
                orientation = Orientation.Horizontal, // 简化为固定横向
                scale = sizeScale
            )
        }
    }
}

@Composable
fun GestureInstructionCard() {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "🎯 手势操作指南",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 看到 E 字方向时
                InstructionSection(
                    title = "✅ 看到 E 字时",
                    instructions = listOf(
                        InstructionItem("E 口朝上", "⬆️", "向上滑动"),
                        InstructionItem("E 口朝下", "⬇️", "向下滑动"),
                        InstructionItem("E 口朝左", "⬅️", "向左滑动"),
                        InstructionItem("E 口朝右", "➡️", "向右滑动")
                    )
                )
                
                Divider(color = MaterialTheme.colorScheme.outline)
                
                // 没看到 E 字时
                InstructionSection(
                    title = "❌ 没看到/看不清时",
                    instructions = listOf(
                        InstructionItem(
                            "左右摆动手掌", 
                            "🖐️", 
                            "像打招呼一样左右摇手"
                        )
                    )
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            AlertMessageBox(
                text = "💡 提示：确保手机摄像头能看到您的手部，并保持适当的光线。",
                icon = "💡"
            )
        }
    }
}

@Composable
fun InstructionSection(title: String, instructions: List<InstructionItem>) {
    Column {
        Text(
            text = title,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        instructions.forEach { item ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "${item.icon} ",
                    fontSize = 20.sp
                )
                Text(
                    text = "${item.label}: ${item.action}",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

data class InstructionItem(
    val label: String,
    val icon: String,
    val action: String
)

@Composable
fun AlertMessageBox(text: String, icon: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = icon, fontSize = 20.sp)
            Text(
                text = text,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onTertiaryContainer
            )
        }
    }
}

@Composable
fun ResultsHistoryCard(results: List<EyeChartResult>) {
    if (results.isEmpty()) return
    
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "📝 测试记录",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(4.dp),
                maxItemsForInitialLayout = 5
            ) {
                items(results.size) { index ->
                    val result = results[results.size - 1 - index]
                    val isError = !result.isCorrect
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "行${result.lineIndex + 1}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        Text(
                            text = when {
                                isError -> "❌ 挥手（没看到）"
                                result.swipeDirection != null -> "✓ 正确"
                                else -> "?"
                            },
                            fontSize = 12.sp,
                            color = if (isError) 
                                MaterialTheme.colorScheme.error 
                            else 
                                MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VisionSummaryCard(summary: Pair<Double, Double>) {
    if (summary.first == 0.0 && summary.second == 0.0) return
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "📊 视力总结",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "最佳视力:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f)
                    )
                    Text(
                        text = "${String.format("%.1f", summary.first)}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
                
                Column {
                    Text(
                        text = "最差视力:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f)
                    )
                    Text(
                        text = "${String.format("%.1f", summary.second)}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            LinearProgressIndicator(
                progress = { summary.first.toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                colors = ProgressIndicatorDefaults.colors(
                    activeColor = MaterialTheme.colorScheme.primary,
                    backgroundColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                )
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "建议定期（每 6-12 个月）进行专业视力检查。本应用仅供娱乐参考。",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f),
                fontStyle = FontStyle.Italic,
                textAlign = TextAlign.Center
            )
        }
    }
}

// 绘制 E 字的辅助函数
enum class Orientation { Horizontal, Vertical }

fun Canvas.drawEye(orientation: Orientation, scale: Float = 1f) {
    val size = size.minDimension
    val strokeThickness = size * 0.08f * scale
    val gap = strokeThickness * 0.3f
    
    val halfSize = size / 2
    
    // 绘制 E 字
    val outlineColor = MaterialTheme.colorScheme.onBackground
    
    translate(
        left = halfSize,
        top = halfSize,
        width = size,
        height = size
    ) {
        rotate(degrees = 0f) { // 简化：不旋转
            // 竖杠
            drawRect(
                color = outlineColor,
                topLeft = Offset(0f, -size / 2),
                size = Size(strokeThickness, size)
            )
            
            // 三个横杠
            drawRect(
                color = outlineColor,
                topLeft = Offset(0f, -size / 3),
                size = Size(size / 2, strokeThickness)
            )
            drawRect(
                color = outlineColor,
                topLeft = Offset(0f, 0f),
                size = Size(size / 2, strokeThickness)
            )
            drawRect(
                color = outlineColor,
                topLeft = Offset(0f, size / 3),
                size = Size(size / 2, strokeThickness)
            )
        }
    }
}
